Hi,
Chess is one of my favourite games, and that is why I made it for free.


Model Name					Triangle Count
Chess Board					628
Bishop						2836
King						2096
Knight						2914
Pawn						2302
Queen						3036
Rook						1704


The marble texture is created by Amada44 and modified by Arcane Cyber.
https://commons.wikimedia.org/wiki/User:Amada44

If you like it, check out my other products in the Asset Store:
https://www.assetstore.unity3d.com/en/#!/query=publisher:18730

If you have any questions feel free to contact me at
arcanecyber@gmail.com